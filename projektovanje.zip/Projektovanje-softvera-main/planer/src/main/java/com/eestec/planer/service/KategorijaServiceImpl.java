package com.eestec.planer.service;

import com.eestec.planer.dao.KategorijaDAO;
import com.eestec.planer.dao.TimDAO;
import com.eestec.planer.dto.KategorijaDTO;
import com.eestec.planer.dto.KoordinatorDTO;
import com.eestec.planer.dto.KorisnikDTO;
import com.eestec.planer.dto.TimDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class KategorijaServiceImpl implements KategorijaService {

    @Autowired
    KategorijaDAO kategorijaDAO;
    @Autowired
    private TimDAO timDAO;

    @Autowired
    public KategorijaServiceImpl(KategorijaDAO kategorijaDAO) {
        this.kategorijaDAO = kategorijaDAO;
    }
        @Override
        public List<KategorijaDTO> getAllKategorije() {
            return kategorijaDAO.findAll();
        }

    @Override
    @Transactional
    public boolean deleteKategorija(Integer id) {
        KategorijaDTO kategorijaDTO = kategorijaDAO.findById(id).orElse(null);
        if (kategorijaDTO != null) {
            kategorijaDAO.delete(kategorijaDTO);
            return true;
        }
        return false;
    }

    public KategorijaDTO updateCategory(int categoryId, String newCategoryName) {
        Optional<KategorijaDTO> optionalKategorija = kategorijaDAO.findById(categoryId);
        if (optionalKategorija.isPresent()) {
            KategorijaDTO kategorija = optionalKategorija.get();
            kategorija.setNaziv(newCategoryName);
            KategorijaDTO updatedKategorija = kategorijaDAO.save(kategorija);
            return updatedKategorija;
        } else {

            return null;
        }
    }

    @Override
    public KategorijaDTO getKategoriju(int idKategorija) {
        return kategorijaDAO.findByIdKategorija(idKategorija);
    }

    public KategorijaDTO createCategory(KategorijaDTO kategorija) {
        return kategorijaDAO.save(kategorija);
    }



}
