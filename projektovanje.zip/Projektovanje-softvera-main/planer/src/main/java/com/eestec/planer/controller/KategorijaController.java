package com.eestec.planer.controller;

import com.eestec.planer.dto.KategorijaDTO;
import com.eestec.planer.dto.KorisnikDTO;
import com.eestec.planer.dto.TimDTO;
import com.eestec.planer.service.KategorijaService;
import com.eestec.planer.service.KategorijaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/category")
@CrossOrigin(origins = "http://localhost:3000")
public class KategorijaController
{
    private final KategorijaServiceImpl kategorijaService;

    @Autowired
    public KategorijaController(KategorijaServiceImpl kategorijaService) {
        this.kategorijaService = kategorijaService;
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<KategorijaDTO>> getAllKategorije() {
        List<KategorijaDTO> kategorije = kategorijaService.getAllKategorije();
        return ResponseEntity.ok(kategorije);
    }
/*  @PostMapping("/createCategory")
  public ResponseEntity<KategorijaDTO> createCategory(@RequestBody KategorijaDTO kategorijaDTO) {
      KategorijaDTO kategorija = kategorijaService.createCategory(kategorijaDTO);
      if (kategorija != null)
          return ResponseEntity.ok(kategorija);
      return ResponseEntity.notFound().build();
  }*/

    @PostMapping("/create")
    public ResponseEntity<KategorijaDTO> createCategory(@RequestBody KategorijaDTO kategorija) {
        KategorijaDTO novaKategorija = kategorijaService.createCategory(kategorija);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaKategorija);
    }

    @DeleteMapping("/delete/{id}")
    //  @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<Void> deleteKategorija(@PathVariable Integer id) {
        boolean isOk = kategorijaService.deleteKategorija(id);
        if (isOk) return ResponseEntity.noContent().build();
        else return ResponseEntity.notFound().build();
    }

    @PutMapping("/{categoryId}")
    public ResponseEntity<KategorijaDTO> updateCategory(
            @PathVariable int categoryId,
            @RequestParam String newCategoryName) {

        KategorijaDTO updatedKategorija = kategorijaService.updateCategory(categoryId, newCategoryName);

        if (updatedKategorija != null) {
            return ResponseEntity.ok(updatedKategorija);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @GetMapping("/get/{idKategorije}")
    public ResponseEntity<KategorijaDTO> getKategorija(@PathVariable int idKategorije) {
        KategorijaDTO kategorija = kategorijaService.getKategoriju(idKategorije);
        if (kategorija != null) {
            return ResponseEntity.ok(kategorija);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
