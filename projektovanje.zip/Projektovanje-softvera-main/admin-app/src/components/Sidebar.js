
function Sidebar () {
    return (
        <div>
            <h1>Pregledi</h1>
            <ul className="my-list-group">
                <li className="my-list-group-item">Zahtjevi za naloge</li>
                <li className="my-list-group-item">Korisnici</li>
            </ul>
        </div>
    )
}

export default Sidebar;