package com.example.EestecPlaner.EestecPlaner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EestecPlanerApplicationTests {

	@Test
	void contextLoads() {
	}

}
