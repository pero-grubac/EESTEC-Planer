package com.example.EestecPlaner.EestecPlaner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EestecPlanerApplication {

	public static void main(String[] args) {

		SpringApplication.run(EestecPlanerApplication.class, args);

	}



}
