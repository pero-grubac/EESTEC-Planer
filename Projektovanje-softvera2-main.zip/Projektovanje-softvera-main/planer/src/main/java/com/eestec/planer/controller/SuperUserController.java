package com.eestec.planer.controller;

import com.eestec.planer.dto.SuperUserDTO;
import com.eestec.planer.service.ObjavaService;
import com.eestec.planer.service.SuperUserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/superuser")
@CrossOrigin(origins = "http://localhost:3000")
public class SuperUserController {


    private final SuperUserServiceImpl superUserService;

    @Autowired
    public SuperUserController(SuperUserServiceImpl superUserService) {
        this.superUserService = superUserService;
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<SuperUserDTO>> getAllSuperUsers() {
        List<SuperUserDTO> superUserDTOList = superUserService.getAllSuperUsers();
        return ResponseEntity.ok(superUserDTOList);
    }

    @PostMapping("/new")
    public ResponseEntity<SuperUserDTO> createSuperUser(@RequestParam Integer id) {
        SuperUserDTO superUserDTO = superUserService.createSuperUser(id);
        if (superUserDTO != null) {
            return ResponseEntity.ok(superUserDTO);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<SuperUserDTO> deleteSuperUser(@PathVariable Integer id) {
        boolean isOK = superUserService.deleteSuperUser(id);
        if (isOK) return ResponseEntity.noContent().build();
        else return ResponseEntity.notFound().build();
    }
/*
    @PostMapping("/notification")
    public ResponseEntity<String> createNotification(@RequestParam String sadrzaj) {


        boolean isOk = superUserService.createNotification(sadrzaj);
        if (isOk) {
            return ResponseEntity.ok("Uspjesna notifikacija.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
*/


/*
*
* @PostMapping("/notification/{idSuperUsera}")
public ResponseEntity<String> createNotification(@RequestBody Map<String, String> request, @PathVariable int idSuperUsera) {
    String sadrzaj = request.get("sadrzaj");

    if (sadrzaj != null) {
        boolean isOk = superUserService.createNotification(sadrzaj, idSuperUsera);
        if (isOk) {
            return ResponseEntity.ok("Uspješna notifikacija.");
        } else {
            return ResponseEntity.notFound().build();
        }
    } else {
        return ResponseEntity.badRequest().build();
    }
}

* */



}
