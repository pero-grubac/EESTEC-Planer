package com.eestec.planer.dao;



import com.eestec.planer.dto.ZadatakDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZadatakDAO extends JpaRepository<ZadatakDTO, Integer> {
    List<ZadatakDTO> findByKategorijaDTO_IdKategorija(int idKategorije);
}