package com.eestec.planer.service;

import com.eestec.planer.dao.KoordinatorDAO;
import com.eestec.planer.dao.KorisnikDAO;
import com.eestec.planer.dao.TimDAO;
import com.eestec.planer.dto.KoordinatorDTO;
import com.eestec.planer.dto.KorisnikDTO;
import com.eestec.planer.dto.TimDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TimServiceImpl implements TimService {

    private TimDAO timDAO;
    private KorisnikDAO korisnikDAO;

 /*   @Autowired
    public TimServiceImpl(TimDAO timDAO, KorisnikDAO korisnikDAO) {
        this.timDAO = timDAO;
        this.korisnikDAO = korisnikDAO;
    }*/
 @Autowired
 public TimServiceImpl(TimDAO timDAO, KorisnikDAO korisnikDAO, KoordinatorDAO koordinatorDAO) {
     this.timDAO = timDAO;
     this.korisnikDAO = korisnikDAO;
     this.koordinatorDAO = koordinatorDAO;
 }
    @Override
    public List<TimDTO> getAllTeams() {
        return timDAO.findAll();
    }

    @Override
    @Transactional
    public TimDTO getTim(Integer id) {
        return timDAO.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public TimDTO createTim(TimDTO timDTO) {
        if (timDAO.save(timDTO) != null)
            return timDTO;
        return null;
    }

    @Override
    public TimDTO updateTim(TimDTO timDTO) {
        if (timDTO != null) {
            timDAO.save(timDTO);
            return timDTO;
        }
        return null;
    }

    @Override
    @Transactional
    public boolean deleteTime(Integer id) {
        TimDTO tim = timDAO.findById(id).orElse(null);
        if (tim != null) {
            timDAO.delete(tim);
            return true;
        }
        return false;
    }
    public  List<KorisnikDTO> getAllByIdTim(Integer idTim){
        return korisnikDAO.getAllByIdTim(idTim);
    }




    private KoordinatorDAO koordinatorDAO;

    /*@Autowired
    public TimServiceImpl(TimDAO timDAO, KoordinatorDAO koordinatorDAO) {
        this.timDAO = timDAO;
        this.koordinatorDAO = koordinatorDAO;
    }*/

}