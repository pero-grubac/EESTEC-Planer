package com.eestec.planer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanerApplicationTests {

	@Test
	void contextLoads() {
	}

}
