package com.eestec.P.eestecP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EestecPApplication {

	public static void main(String[] args) {
		SpringApplication.run(EestecPApplication.class, args);
	}

}
